// Supabase Edge Function: identifies a mineral from a photo using Claude.
// The Anthropic key lives ONLY here, as a secret. Never put it in the app.
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
};
const j = (o: unknown, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

const prompt = (lang: string) => {
  const l = lang === "fr" ? "français" : "Kiswahili";
  return `Tu es géologue. Regarde cette photo d'un minéral ou d'une roche. Réponds en ${l}, court (max 170 mots):
1) les 3 minéraux les plus probables avec indices visibles (couleur, éclat, forme, cristaux);
2) un niveau de confiance honnête;
3) 3 tests simples pour confirmer (trait, dureté, aimant, acide);
4) un avertissement si le minéral peut être toxique ou radioactif.
Ne donne ni prix ni avis sur la légalité. Une photo ne suffit jamais pour une certitude: dis-le.`;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization") || "";
    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY") ?? req.headers.get("apikey")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: { user } } = await sb.auth.getUser();
    if (!user) return j({ error: "login" }, 401);

    const since = new Date(Date.now() - 864e5).toISOString();
    const { count } = await sb.from("ident_log").select("*", { count: "exact", head: true }).gte("created_at", since);
    if ((count ?? 0) >= 10) return j({ error: "limit" }, 429);

    const { image, mime, lang } = await req.json();
    if (!image || typeof image !== "string" || image.length > 1_500_000) return j({ error: "image" }, 400);
    await sb.from("ident_log").insert({});

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-sonnet-5-5",
        max_tokens: 700,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mime || "image/jpeg", data: image } },
            { type: "text", text: prompt(lang) },
          ],
        }],
      }),
    });
    const d = await r.json();
    if (!r.ok) return j({ error: "api", detail: d?.error?.message }, 502);
    return j({ text: (d.content || []).map((c: { text?: string }) => c.text || "").join("") });
  } catch (_e) {
    return j({ error: "server" }, 500);
  }
});
