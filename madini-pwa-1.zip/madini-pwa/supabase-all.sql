-- MADINI: full database setup. Safe to run more than once (idempotent).
-- Supabase > SQL Editor > New query > paste ALL > Run.

create table if not exists public.profiles(uid uuid primary key references auth.users(id) on delete cascade, name text not null default 'Mtumiaji', created_at timestamptz not null default now());
create table if not exists public.posts(id bigint generated always as identity primary key, created_at timestamptz not null default now(), uid uuid not null default auth.uid() references auth.users(id) on delete cascade, name text, st int not null default 1, seller text, lic text, country text, city text, village text, price text, tel text, descr text, img text);
alter table public.posts add column if not exists kind text not null default 'sell';
alter table public.posts alter column seller drop not null;
alter table public.posts alter column country drop not null;
create table if not exists public.comments(id bigint generated always as identity primary key, post_id bigint not null references public.posts(id) on delete cascade, uid uuid not null default auth.uid() references auth.users(id) on delete cascade, body text not null check (char_length(body) between 1 and 500), created_at timestamptz not null default now());
alter table public.comments add column if not exists best boolean not null default false;
create table if not exists public.likes(post_id bigint references public.posts(id) on delete cascade, uid uuid default auth.uid() references auth.users(id) on delete cascade, primary key(post_id,uid));
create table if not exists public.reports(post_id bigint references public.posts(id) on delete cascade, uid uuid default auth.uid() references auth.users(id) on delete cascade, primary key(post_id,uid));
create table if not exists public.ident_log(id bigint generated always as identity primary key, uid uuid not null default auth.uid() references auth.users(id) on delete cascade, created_at timestamptz not null default now());
create table if not exists public.collection(id bigint generated always as identity primary key, uid uuid not null default auth.uid() references auth.users(id) on delete cascade, name text not null, place text, note text, img text, created_at timestamptz not null default now());
create table if not exists public.follows(uid uuid default auth.uid() references auth.users(id) on delete cascade, term text not null check (char_length(term) between 1 and 40), primary key(uid,term));

-- Auto-create a profile for each new user, and backfill existing users
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(uid,name) values(new.id, left(coalesce(nullif(new.raw_user_meta_data->>'name',''), split_part(new.email,'@',1)),40)) on conflict do nothing; return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
insert into public.profiles(uid,name) select id, left(split_part(email,'@',1),40) from auth.users on conflict do nothing;

-- Leaderboard: points = comments chosen as best by the post owner
create or replace view public.leaderboard as select p.uid, p.name, count(c.id) filter (where c.best) as pts from public.profiles p left join public.comments c on c.uid=p.uid group by p.uid, p.name;
grant select on public.leaderboard to anon, authenticated;

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.reports enable row level security;
alter table public.ident_log enable row level security;
alter table public.collection enable row level security;
alter table public.follows enable row level security;

drop policy if exists "profiles read" on public.profiles; create policy "profiles read" on public.profiles for select using (true);
drop policy if exists "profiles insert own" on public.profiles; create policy "profiles insert own" on public.profiles for insert to authenticated with check (uid = auth.uid());
drop policy if exists "profiles update own" on public.profiles; create policy "profiles update own" on public.profiles for update to authenticated using (uid = auth.uid()) with check (uid = auth.uid());
drop policy if exists "posts read" on public.posts; create policy "posts read" on public.posts for select using (true);
drop policy if exists "posts add" on public.posts; create policy "posts add" on public.posts for insert to authenticated with check (uid = auth.uid());
drop policy if exists "posts update own" on public.posts; create policy "posts update own" on public.posts for update to authenticated using (uid = auth.uid()) with check (uid = auth.uid());
drop policy if exists "posts delete own" on public.posts; create policy "posts delete own" on public.posts for delete to authenticated using (uid = auth.uid());
drop policy if exists "comments read" on public.comments; create policy "comments read" on public.comments for select using (true);
drop policy if exists "comments add" on public.comments; create policy "comments add" on public.comments for insert to authenticated with check (uid = auth.uid());
drop policy if exists "comments delete own" on public.comments; create policy "comments delete own" on public.comments for delete to authenticated using (uid = auth.uid());
drop policy if exists "comments best by post owner" on public.comments; create policy "comments best by post owner" on public.comments for update to authenticated using (exists(select 1 from public.posts p where p.id=comments.post_id and p.uid=auth.uid())) with check (comments.uid <> auth.uid());
-- only the 'best' column may be changed on comments
revoke update on public.comments from authenticated;
grant update(best) on public.comments to authenticated;
drop policy if exists "likes read" on public.likes; create policy "likes read" on public.likes for select using (true);
drop policy if exists "likes add" on public.likes; create policy "likes add" on public.likes for insert to authenticated with check (uid = auth.uid());
drop policy if exists "reports read" on public.reports; create policy "reports read" on public.reports for select using (true);
drop policy if exists "reports add" on public.reports; create policy "reports add" on public.reports for insert to authenticated with check (uid = auth.uid());
drop policy if exists "likes delete own" on public.likes; create policy "likes delete own" on public.likes for delete to authenticated using (uid = auth.uid());
drop policy if exists "ident read own" on public.ident_log; create policy "ident read own" on public.ident_log for select to authenticated using (uid = auth.uid());
drop policy if exists "ident add own" on public.ident_log; create policy "ident add own" on public.ident_log for insert to authenticated with check (uid = auth.uid());
drop policy if exists "collection read own" on public.collection; create policy "collection read own" on public.collection for select to authenticated using (uid = auth.uid());
drop policy if exists "collection add" on public.collection; create policy "collection add" on public.collection for insert to authenticated with check (uid = auth.uid());
drop policy if exists "collection delete own" on public.collection; create policy "collection delete own" on public.collection for delete to authenticated using (uid = auth.uid());
drop policy if exists "follows read own" on public.follows; create policy "follows read own" on public.follows for select to authenticated using (uid = auth.uid());
drop policy if exists "follows add" on public.follows; create policy "follows add" on public.follows for insert to authenticated with check (uid = auth.uid());
drop policy if exists "follows delete own" on public.follows; create policy "follows delete own" on public.follows for delete to authenticated using (uid = auth.uid());

-- Photo storage
insert into storage.buckets(id,name,public) values ('minerals','minerals',true) on conflict do nothing;
drop policy if exists "minerals read" on storage.objects; create policy "minerals read" on storage.objects for select using (bucket_id='minerals');
drop policy if exists "minerals upload" on storage.objects; create policy "minerals upload" on storage.objects for insert to authenticated with check (bucket_id='minerals' and (storage.foldername(name))[1]=auth.uid()::text);
